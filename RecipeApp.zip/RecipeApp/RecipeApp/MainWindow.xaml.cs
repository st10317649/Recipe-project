﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RecipeApp
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Recipe> Recipes { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            Recipes = new ObservableCollection<Recipe>();
            btnAddRecipe.Click += BtnAddRecipe_Click;
            btnDisplayRecipes.Click += BtnDisplayRecipes_Click;
            btnScaleRecipe.Click += BtnScaleRecipe_Click;
            btnDeleteRecipe.Click += BtnDeleteRecipe_Click;
        }

        private void BtnAddRecipe_Click(object sender, RoutedEventArgs e)
        {
            contentArea.Content = new AddRecipeControl();
        }

        private void BtnDisplayRecipes_Click(object sender, RoutedEventArgs e)
        {
            contentArea.Content = new DisplayRecipesControl();
        }

        private void BtnScaleRecipe_Click(object sender, RoutedEventArgs e)
        {
            contentArea.Content = new ScaleRecipeControl();
        }

        private void BtnDeleteRecipe_Click(object sender, RoutedEventArgs e)
        {
            contentArea.Content = new DeleteRecipeControl();
        }
    }
}