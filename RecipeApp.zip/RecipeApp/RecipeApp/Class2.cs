﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApp
{
     // Class representing a recipe
    public class Recipe
    {
        // Properties of a recipe
        public string Name { get; set; } // Name of the recipe
        public List<Ingredient> Ingredients { get; set; } // List of ingredients in the recipe

        // Constructor to initialize a recipe object
        public Recipe()
        {
            Ingredients = new List<Ingredient>();
        }

        // Method to calculate the total calories of the recipe
        public int CalculateTotalCalories()
        {
            int totalCalories = 0;
            foreach (var ingredient in Ingredients)
            {
                totalCalories += ingredient.Calories * Convert.ToInt32(ingredient.Quantity); // Calculate total calories based on quantity of each ingredient
            }
            return totalCalories;
        }
    }
}
